package gdu.k16.demoflutter_221407

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
