import 'package:flutter/material.dart';
import 'Cong2soWidget.dart';
import 'ButtonSection.dart';

class Home extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Center(
      child: ListView(
        children: [
          Image.network(
              "https://giadinh.edu.vn/upload/elfinder/2024/DSC_2026.jpg"),
          SizedBox(height: 10),
          ButtonSection(),
          SizedBox(height: 10),
          Center(
            child: Text(
              "Có một mùa hoa cải.\n Nở rộ trên bến sông.\nEm đang thì con gái.\nĐợi anh chưa lấy chồng",
              style: TextStyle(
                fontSize: 18,
                color: Colors.blue[500],
              ),
            ),
          ),
          SizedBox(height: 10),
        ],
      ),
    );
  }
}
