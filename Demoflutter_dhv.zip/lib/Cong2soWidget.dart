import 'package:flutter/material.dart';

class Cong2soWidget extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return Trangthaicong2so();
  }
}

class Trangthaicong2so extends State<Cong2soWidget> {
  double ketqua = 0;
  String message = "";

  bool? namnu = false;

  TextEditingController txt1 = TextEditingController();
  TextEditingController txt2 = TextEditingController();

  void cong() {
    double sothunhat = 0;
    double sothuhai = 0;
    double kq = 0;

    try {
      sothunhat = double.parse(txt1.text.toString());
      sothuhai = double.parse(txt2.text.toString());
      kq = sothunhat + sothuhai;
      setState(() {
        ketqua = kq;
        message = "";
      });
    } catch (e) {
      setState(() {
        message = e.toString();
        ketqua = 0;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height,
      child: Column(
        children: [
          Text("CỘNG 2 SỐ",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 20,
                color: Color(0xff06345a),
              )),
          SizedBox(height: 10),
          TextField(
            controller: txt1,
            decoration: InputDecoration(hintText: "Số thứ nhất"),
            style: TextStyle(fontSize: 20),
          ),
          TextField(
            controller: txt2,
            decoration: InputDecoration(hintText: "Số thứ hai"),
            style: TextStyle(fontSize: 20),
          ),
          Checkbox(
            isError: true,
            tristate: true,
            value: namnu,
            onChanged: (bool? value) {
              setState(() {
                namnu = value;
              });
            },
          ),
          (namnu == true)
              ? Container(
                  width: 100,
                  child: Image.network(
                      "https://cdn-icons-png.flaticon.com/512/2042/2042895.png"),
                )
              : Container(
                  width: 100,
                  child: Image.network(
                      "https://as1.ftcdn.net/v2/jpg/01/54/63/22/1000_F_154632264_mzeBfVl6QdkDLhVKWOAkTZvTIgICwfwZ.jpg"),
                ),
          SizedBox(height: 10),
          Text(
            ketqua.toString(),
            style: TextStyle(fontSize: 20),
          ),
          Text(message, style: TextStyle(fontSize: 20, color: Colors.red)),
          SizedBox(
            height: 20,
          ),
          ElevatedButton(
              onPressed: cong,
              child: Text(
                "Cộng 2 số",
                style: TextStyle(fontSize: 20),
              ))
        ],
      ),
    );
  }
}
