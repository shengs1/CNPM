import 'package:demoflutter_221407/Cong2soWidget.dart';
import 'package:flutter/material.dart';
import 'Home.dart';
import 'Page1.dart';
import 'ListProducts.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'CartScreen.dart';
import 'ListProducts_Admin.dart';
import 'ListProductsAPI.dart';
import 'models/Product.dart';
import 'TestHashing.dart';
import 'ListProductsFirebase.dart';
import 'chat_screen.dart';

class MyLayout extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return MyLayout_State();
  }
}

class MyLayout_State extends State<MyLayout> {
  late Future<List<Product>> lstproducts;

  int _selectedIndex = 0;
  final List<Widget> _pages = [
    ListProductsAPI(),
    ListProductsFirebase(),
    CartScreen()
  ];

  final List<String> _carouselImages = [
    'https://cdn2.tuoitre.vn/thumb_w/730/471584752817336320/2023/11/16/photo-1700106734216-17001067345921150516868.jpg',
    'https://hung-vuong-prd.sgp1.digitaloceanspaces.com/hung-vuong/imgs/576962656a514e52644a73615a67554850624b6f70.png',
    'https://hung-vuong-prd.sgp1.digitaloceanspaces.com/hung-vuong/imgs/4547627479726647616d3557375a69626150524670.png',
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(150), // Điều chỉnh chiều cao AppBar
        child: AppBar(
          toolbarHeight: 150,
          title: CarouselSlider(
            items: _carouselImages
                .map((imageUrl) => ClipRRect(
                      borderRadius: BorderRadius.circular(5.0),
                      child: AspectRatio(
                        aspectRatio: 16 / 7,
                        child: Image.network(
                          imageUrl,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ))
                .toList(),
            options: CarouselOptions(
              height: 150,
              autoPlay: true,
              autoPlayInterval: Duration(seconds: 3),
              enlargeCenterPage: true,
              viewportFraction: 1.0,
            ),
          ),
          actions: [
            PopupMenuButton<String>(
              onSelected: (value) {
                if (value == 'products') {
                  // ScaffoldMessenger.of(context).showSnackBar(
                  //     SnackBar(content: Text('Chuyển đến Quản lý sản phẩm')));
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => ListProducts_Admin()),
                  );

                  // Điều hướng sang trang Quản lý sản phẩm nếu có
                } else if (value == 'categories') {
                  ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Chuyển đến Quản lý danh mục')));
                  // Điều hướng sang trang Quản lý danh mục nếu có
                }
              },
              itemBuilder: (BuildContext context) => <PopupMenuEntry<String>>[
                PopupMenuItem<String>(
                  value: 'products',
                  child: Text('Quản lý sản phẩm'),
                ),
                PopupMenuItem<String>(
                  value: 'categories',
                  child: Text('Quản lý danh mục'),
                ),
              ],
            ),
          ],
        ),
      ),
      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.list),
            label: 'Products',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.shopping_cart),
            label: 'Cart',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Color(0xffed10a2),
        onTap: _onItemTapped,
      ),
    );
  }
}
